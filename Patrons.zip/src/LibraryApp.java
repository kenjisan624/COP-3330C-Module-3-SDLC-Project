/*
Project: LMS Software Development Life Cycle Project Part 2
Name: Kenji Nakanishi
Course and CRN: Software Development I & 14877
Professor: Lisa Macon

This is the Main App where the application is going to run the NavigatonMenu containing the
outline of the system CLI where the librarian can select what actions to perform.
*/
public class LibraryApp {
	public static void main(String[] args) {
        new NavigationMenu().start();
	}
}